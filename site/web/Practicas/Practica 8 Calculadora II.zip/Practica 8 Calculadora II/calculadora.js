var calculadora = calculadora || {};

calculadora = function()
{
    function init()
    {
        
    }

    function suma(a,b)
    {
        return parseInt(a)+parseInt(b)
    }

      function resta(a,b){
        return parseInt(a)-parseInt(b)
    }

    function factorial(a){
        factorial = a;
        resultado = 1;
        while(factorial>0){
            resultado *= factorial;
            factorial--;
        }

    return parseInt(resultado);
    }


    function printButtons()
    {
    	return '<button onclick="'+
    	'document.getElementById(\'resultado\').innerHTML =	'+
    	'Calculadora.suma( document.getElementById(\'op1\').value '+
    	', document.getElementById(\'op2\').value )'+
    	'">SUMA</button><button onclick="'+
        'document.getElementById(\'resultado\').innerHTML = '+
        'Calculadora.resta(document.getElementById(\'op1\').value '+
        ', document.getElementById(\'op2\').value )'+
        '">RESTA</button><button onclick="'+
        'document.getElementById(\'resultado\').innerHTML = '+
        'Calculadora.factorial(document.getElementById(\'op1\').value '+
        ', document.getElementById(\'op2\').value )'+
        '">FACTORIAL</button>';
    }

    /**
     * Ejecutable al cargar la página
     */

     init()
    

    /**
     * Public
     */
     return {
        version: function() {
            return version;
        }
        ,init: init
        ,suma: suma
        ,resta: resta
        ,factorial: factorial
        ,printButtons : printButtons
        
    }
};